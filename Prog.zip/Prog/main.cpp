#include <iostream>
#include <conio.h>
#include <fstream>
#include <string.h>
#include <vector>
#include <sstream>
using namespace std;

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

class Usuario{
	public:
	char Nome[60];
	char Email[60];
	char Endereco[60];
	char Senha[100];
	char ConfirmaSenha[100];
	int k;
	int j;
	
	void senha(){
		

		
				printf ("\nDigite uma senha:  ");
			k=0;
			    while(Senha[k-1]!='\r') 
				{
			    	
			    	Senha[k] = getch();
			    	if(Senha[k-1]!='\r') {
			    		cout<<"";
			    	}
			    	++k;
			    }
			
			printf ("\nConfirme a senha:  ");
			j=0;
			    while(ConfirmaSenha[j-1]!='\r') 
				{
			    	
			    	ConfirmaSenha[j] = getch();
			    	if(ConfirmaSenha[j-1]!='\r') {
			    		cout<<"";
			    	}
			    	++j;
			    }
	
	}
	void gravaDB(){
		fstream fout;
		 fout.open("database.csv", ios::out | ios::app);
		 fout<<Nome<<";"<<Email<<";"<<Endereco<<";"<<Senha<<"\n";
	}
	void lerDB() {
		fstream fin;
		vector<string> content;
		vector<string> row;
		string line, word;
		fstream file("database.csv", ios::in);
			
	}
};



int main(int argc, char** argv) {
	int option=0;
	printf ("Bem Vindo ao Zeca Delivery \n");
	printf ("************************** \n");
	printf ("Digite a opcao desejada e aperte Enter \n");
	printf ("1- Login \t2- Novo Usuario\n");
	cin >> option;
	
	switch(option)
	{
		
		case 1:
		Usuario login;
		printf ("\nDigite o email cadastrado:  ");
		cin >> login.Email;
		
		printf ("\nDigite sua Senha:  ");
		cin >> login.Senha;
		
		
		case 2:
			int i;
			Usuario novo;
			
			
			
			printf ("Digite seu nome:  ");
            fflush(stdin);
            scanf("%[^\n]", novo.Nome);
			
			getch();		
			
			printf ("\nDigite seu email:  ");
			cin >> novo.Email;

			getch();	
			
			printf ("\nDigite seu endereco:  ");
            fflush(stdin);
            scanf("%[^\n]", novo.Endereco);
			
			getch();	
			
			novo.senha();
			while (strcmp(novo.Senha,novo.ConfirmaSenha)!=0)
			{
				printf ("\nSenhas nao coincidem, tente novamente \n ");
				printf ("Senha:  %s\n ",novo.Senha );
				printf ("Confirma Senha:  %s\n ",novo.ConfirmaSenha );
				novo.senha();
			}
			
			novo.gravaDB();
			cout<<"\nUsuario cadastrado com sucesso!\n";
			getch();


	
	}
	
	
	
	
	
	return 0;
}
